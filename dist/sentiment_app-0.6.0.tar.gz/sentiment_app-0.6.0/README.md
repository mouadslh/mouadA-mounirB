# sentiment-app : dépôt du binôme

Application fil rouge du cours *Développement et déploiement d'applications intelligentes*.
Le dépôt couvre les TP1 à TP6 : cadrage, modèle, API, qualité, interface et paquet Python installable.

## Démarrage rapide

```bash
python -m venv .venv
source .venv/bin/activate        # Windows PowerShell : .venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Pour installer le paquet et sa commande pendant le développement :

```bash
pip install -e ".[ui]"
sentiment --version
sentiment predict "Livraison rapide, produit conforme, très satisfait"
sentiment serve       # API FastAPI
sentiment ui          # interface Streamlit
```

Le modèle se régénère avec `python src/train.py`. Pour une installation de la roue,
indiquez son chemin avec `SENTIMENT_MODELE` si le fichier n'est pas à l'emplacement
`models/sentiment.joblib` de l'installation.

Puis vérifiez :

```bash
python scripts/check_setup.py    # diagnostic lisible : versions, dossiers, Git, fiches
pytest -q                        # les mêmes vérifications, sous forme de tests
```

Les résultats attendus de pytest évoluent au fil des TP. Consultez le journal de séance et l’énoncé correspondant ; la suite complète inclut les tests d’intégration et de packaging du TP6.

Les scripts `scripts/setup.sh` (Linux, macOS, Git Bash) et `scripts/setup.ps1` (Windows) font l'installation et le diagnostic en une commande.

## Par où commencer

| Fichier | Quand le lire |
| --- | --- |
| `MARCHE-A-SUIVRE.md` | Pendant la séance : huit étapes, huit contrôles, les résultats attendus |
| `TP1-ENONCE.md` | L'énoncé du TP : objectifs, livrables, grille de notation |
| `TP6-ENONCE.md`, `MARCHE-A-SUIVRE-TP6.md` | L'énoncé et le guide pratique du paquet installable |
| `docs/journal-tp1-tp6.md` | Résultats observés et journal du binôme |
| `docs/tester-la-commande-sentiment.md` | Tester manuellement ou automatiquement la commande du TP6 |
| `TESTS.md` | La démarche de test en détail, et les trois états de référence |
| `AIDE-GIT.md` | Les commandes Git du TP et la résolution d'un conflit |
| `DEPANNAGE.md` | Quand quelque chose échoue |
| `docs/cadrage/GRILLE-DE-DECISION.md` | Pendant la partie A, pour remplir les fiches |
| `exemples/README.md` | Après le TP, pour voir à quoi ressembleront les semaines 2 et 5 |

## Raccourcis

Sous Linux, macOS et Git Bash, un `Makefile` évite de retaper les commandes :

```bash
make setup          # venv, dépendances, diagnostic
make check          # diagnostic seul
make test           # la suite de tests du dépôt
make test-cadrage   # les 12 tests des fiches
make verif URL=https://github.com/<organisation>/sentiment-app.git
make exemple-ml     # entraîne le modèle d'exemple (facultatif)
make help           # la liste complète
```

## Structure

```text
sentiment-app/
├── README.md, guides et énoncés des TP1 à TP6
├── CHANGELOG.md         # versions 0.1.0 à 0.6.0
├── Makefile              # raccourcis (optionnel)
├── requirements.txt      # dépendances du semestre, versions figées
├── .gitignore, .env.example, .editorconfig, pytest.ini
├── .vscode/              # interpréteur et tests préconfigurés
├── data/                 # jeux de données (DVC à partir de la semaine 7)
├── models/               # modèles entraînés (jamais dans Git)
├── api/                  # API FastAPI (semaine 3)
├── ui/                   # interface Streamlit (semaine 5)
├── sentiment_app/        # paquet installable et commande sentiment (TP6)
├── tests/                # tests pytest des TP1 à TP6
├── scripts/              # setup, diagnostic, création de fiche, init du dépôt, clone de vérification
├── notebooks/            # variante Colab du TP1
└── docs/cadrage/         # fiches de cadrage, exemple corrigé, grille, banque de cas
```

## Membres du binôme

| Rôle | Nom | Identifiant GitHub | Répartition des tâches (TP1 à TP6) |
| --- | --- | --- | --- |
| Membre A | Mouad Salah | [@mouadslh](https://github.com/mouadslh) | **TP1 :** environnement Python 3.11, diagnostic de build et CI GitHub Actions. **TP2 :** pipeline scikit-learn, entraînement Allociné et analyse des erreurs. **TP3 :** architecture FastAPI, schémas Pydantic et tests d'API. **TP4 :** tests limites et Hypothesis, courbe de seuil, abstention à 0,60 et rapport TP4. **TP5 :** kit TP5, CI Streamlit et recette des contrôles T29 à T31. **TP6 :** déplacement du prédicteur dans le paquet, raccord de l'API et compatibilité. |
| Membre B | Elhamss Med Mounir | [@mounir-med](https://github.com/mounir-med) | **TP1 :** création du dépôt GitHub, cadrage multicritère et documentation initiale. **TP2 :** cadrage métier et validation des métriques et du seuil F1 macro. **TP3 :** vérification des endpoints, tests Swagger et démarrage fail-fast. **TP4 :** jeu d'or et cas difficiles, tests d'intégration et erreurs 500, configuration de ruff, mypy et pre-commit. **TP5 :** recette T32-T33, ingestion et export CSV, réponses TP5, mise à jour du journal et du rapport. **TP6 :** commande, roue, compte rendu et étiquette de version. |
